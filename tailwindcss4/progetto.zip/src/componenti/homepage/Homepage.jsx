import { Header } from "./header";
import { Navbar } from "./navbar";

export function Homepage() {
  return (
    <div className="m-0">
      <Navbar />
      <Header />
    </div>
  );
}
